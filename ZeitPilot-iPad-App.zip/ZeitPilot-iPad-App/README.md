# ZeitPilot – persönliche Zeiterfassung (Prototyp 1.0)

Eine statische Web-App (PWA) für iPad und Windows-PC. Keine Registrierung, kein VBA, kein kostenpflichtiges Microsoft-365-Abo nötig.

## Funktionen

- Großer Arbeitsbeginn-/Arbeitsende-Button. **Die Uhrzeit wird sofort beim Tippen lokal gesichert**, unabhängig davon, wie lange GPS benötigt.
- Einmalige GPS-Standortabfrage beim Start und Ende; Koordinaten werden lokal gespeichert. Falls du keinen GPS-Zugriff erlaubst, werden die Zeiten trotzdem erfasst.
- Optional Ortsnamen über OpenStreetMap Nominatim ermitteln (dazu werden die GPS-Koordinaten an einen fremden Dienst übertragen; in der App ausdrücklich aktivierbar).
- Arbeitsschichten können beliebig über Mitternacht gehen; mehrere Einsätze pro Tag sind möglich.
- Nächtliche Stunden werden getrennt für jeden Kalendertag berechnet: 00:00–06:00 Uhr und 22:00–00:00 Uhr.
- Einsätze nachtragen, korrigieren, löschen.
- Echter XLSX-Export in 3 Blättern: **Arbeitszeiten**, **Nachtstunden**, **Tagesübersicht**.
- Backup und Wiederherstellung als JSON-Datei. Angezeigte Dezimalstunden werden auf Viertelstunden gerundet. Originalzeitstempel bleiben sekundengetreu gespeichert.

## Einrichtung (einfacher, kostenloser Weg: GitHub Pages)

1. Entpacke diese ZIP-Datei. Die Dateien `index.html`, `app.js`, `logic.js`, `xlsx.js`, `style.css`, `manifest.webmanifest`, `sw.js`, `icon.svg`, `icon-180.png`, `icon-512.png` gehören zusammen.
2. Erstelle unter https://github.com/ ein **öffentliches Repository** (z. B. `zeitpilot-app`). Lade die genannten Dateien in das Stammverzeichnis hoch. **Keine personenbezogenen Arbeitszeitdaten oder JSON-Backups in dieses Repository hochladen!** Dort steht ausschließlich die App-Software.
3. Im Repository: **Settings → Pages → Build and deployment → Deploy from a branch → `main` / (root) → Save**. Nach einigen Minuten wird dir die HTTPS-Adresse der App angezeigt.
4. Öffne diese Adresse auf dem iPad in Safari. **Teilen → Zum Home-Bildschirm**. Die App dort starten. Im iPad die Standortfreigabe für Safari bzw. die Web-App zulassen.
5. Beim ersten Klick Arbeitsbeginn, beim nächsten Arbeitsende. Unter **Export & Sicherung** kannst du die Excel-Datei via Teilen in OneDrive speichern; der Windows-PC kann sie dann in Excel öffnen.
6. Regelmäßig ein JSON-Backup in OneDrive/iCloud Drive sichern. Zum Übernehmen der kompletten Datensammlung auf den Windows-PC dort dieselbe Web-App öffnen und **Backup einlesen** wählen.

**Für Tests auf dem eigenen Windows-PC** kannst du statt Hosting aus diesem Verzeichnis `python -m http.server 8765` starten und die App unter `http://localhost:8765` besuchen. Per normalem Doppelklick auf `index.html` funktionieren Browsermodule und GPS häufig nicht; HTTPS oder localhost ist erforderlich.

## Einschränkungen (bewusst in Version 1)

- **Keine automatische Gerätesynchronisierung:** iPad und Windows haben jeweils eigene lokale Daten. Ein JSON-Backup ist die Übertragungs-/Wiederherstellungsmöglichkeit. Ein XLSX-Export ist eine Auswertung, kein Ersatz für das Backup.
- Browser- bzw. App-Daten können beim Löschen des Website-Speichers verlorengehen. Ein externes Backup ist deshalb unbedingt empfohlen.
- Zum Erfassen ist keine Internetverbindung nötig, sobald die PWA korrekt installiert und zwischengespeichert wurde. GPS-Erfolg und Genauigkeit hängen vom iPad, Berechtigungen und Empfang ab. Eine automatische Ortsnamen-Suche braucht Internet.
- Keine automatische Erkennung des tatsächlichen Standorts *während* einer Schicht (z. B. um Mitternacht). Der Nachtstundenexport führt die beiden **erfassten** Standorte der zugehörigen Schicht auf, ohne zu behaupten, dass man dort zur Nachtzeit war.
- Die App exportiert nur **beendete** Einsätze nach Excel; ein laufender Einsatz erscheint erst nach dem Ausstempeln im Export.
- Monats- und Tageswerte werden aus minutengenauen bzw. sekundengetreuen Zeitstempeln berechnet, dann auf 0,25 Stunden gerundet. Bei tageweisen Rundungen kann die Summe geringfügig von der Gesamtrundung abweichen.
- Eine öffentliche GitHub-Pages-Webadresse stellt nur die **App-Software** öffentlich bereit, **keine** lokal gespeicherten Arbeitsdaten. Andere Personen, die auf demselben entsperrten Gerät Zugang zu deiner App haben, können die dortigen Daten sehen.
- Diese Version hat noch keinen Benutzer-Login, keine serverseitige Cloud-Datenbank und keinen vollständigen Produktions-/Sicherheitsaudit.

## Technische Informationen

Pure HTML/CSS/JavaScript-Module, Web Geolocation API, `localStorage`, Service Worker für PWA-Offline-Dateien. XLSX wird direkt im Browser ohne Drittbibliotheken als Office-Open-XML-ZIP-Paket erzeugt.

Stand: 14. Oktober 2026.
