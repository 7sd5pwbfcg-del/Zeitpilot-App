// Reine Berechnungsfunktionen. Alle Grenzen werden in lokaler Gerätezeit berechnet.
export const QUARTER_MS = 15 * 60 * 1000;
export const hoursRounded = ms => Math.round(Math.max(0, ms) / QUARTER_MS) / 4;
export const isValidDate = value => value && !Number.isNaN(new Date(value).getTime());
export const startOfDay = date => new Date(date.getFullYear(), date.getMonth(), date.getDate());
export const nextDay = date => new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
export const localKey = date => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
export const monthKey = date => localKey(date).slice(0,7);
export const dateText = date => new Intl.DateTimeFormat('de-DE', {day:'2-digit',month:'2-digit',year:'numeric'}).format(date);
export const timeText = date => new Intl.DateTimeFormat('de-DE', {hour:'2-digit',minute:'2-digit',hour12:false}).format(date);
export const dateTimeText = date => `${dateText(date)} ${timeText(date)}`;
export const decimalText = n => n.toLocaleString('de-DE',{minimumFractionDigits:2,maximumFractionDigits:2});
export function locationText(loc) {
  if (!loc) return 'Nicht erfasst';
  if (loc.name?.trim()) return loc.name.trim();
  if (Number.isFinite(loc.lat) && Number.isFinite(loc.lon)) return `${loc.lat.toFixed(5)}, ${loc.lon.toFixed(5)}`;
  return 'Nicht erfasst';
}
function overlap(start,end,a,b) {
  const s=Math.max(start.getTime(),a.getTime()), e=Math.min(end.getTime(),b.getTime());
  return e>s ? {start:new Date(s),end:new Date(e),ms:e-s} : null;
}
export function splitNight(shift) {
  if (!isValidDate(shift.start)||!isValidDate(shift.end)) return [];
  const start=new Date(shift.start), end=new Date(shift.end);
  if (end<=start) return [];
  const out=[];
  // Jeder Kalendertag kann einen Morgen- und einen Abendanteil enthalten.
  for(let day=startOfDay(start), i=0;day<end && i<400;day=nextDay(day),i++) {
    const morningEnd=new Date(day.getFullYear(),day.getMonth(),day.getDate(),6);
    const nightStart=new Date(day.getFullYear(),day.getMonth(),day.getDate(),22);
    for(const [kind,a,b] of [['Morgen',day,morningEnd],['Abend',nightStart,nextDay(day)]]) {
      const part=overlap(start,end,a,b);
      if(part) out.push({shiftId:shift.id,day:localKey(day),kind,...part,
        startLoc:shift.startLoc||null,endLoc:shift.endLoc||null});
    }
  }
  return out;
}
export function splitDays(shift) {
  if(!isValidDate(shift.start)||!isValidDate(shift.end)) return [];
  const start=new Date(shift.start),end=new Date(shift.end);
  if(end<=start) return [];
  const out=[];
  for(let day=startOfDay(start),i=0;day<end && i<400;day=nextDay(day),i++) {
    const part=overlap(start,end,day,nextDay(day));
    if(part) out.push({shiftId:shift.id,day:localKey(day),...part});
  }
  return out;
}
export function monthlySummary(shifts,month,active=null,now=new Date()) {
  const rows=new Map();
  const all=active && new Date(active.start)<now ? [...shifts,{...active,end:now.toISOString()}]:shifts;
  for(const shift of all){
    for(const part of splitDays(shift)) if(part.day.startsWith(month)){
      const row=rows.get(part.day)||{day:part.day,workedMs:0,nightMs:0};
      row.workedMs+=part.ms; rows.set(part.day,row);
    }
    for(const part of splitNight(shift)) if(part.day.startsWith(month)) {
      const row=rows.get(part.day)||{day:part.day,workedMs:0,nightMs:0};
      row.nightMs+=part.ms; rows.set(part.day,row);
    }
  }
  return [...rows.values()].sort((a,b)=>a.day.localeCompare(b.day));
}
export function validateShift(shift) {
  return Boolean(shift && typeof shift.id==='string' && isValidDate(shift.start) && isValidDate(shift.end)
   && new Date(shift.end)>new Date(shift.start)
   && new Date(shift.end)-new Date(shift.start)<400*86400000);
}
