import {splitNight, monthlySummary, hoursRounded, dateText, timeText, locationText, splitDays} from './logic.js';
const esc = x=>String(x??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
const col=n=>{let s='';while(n){n--;s=String.fromCharCode(65+n%26)+s;n=Math.floor(n/26);}return s;};
const txt=s=>({t:'s',v:s??''});
const num=(n,style=3)=>({t:'n',v:Number(n)||0,s:style});
const excelDate=d=>Date.UTC(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours(),d.getMinutes(),d.getSeconds())/86400000+25569;
const dte=d=>num(excelDate(d),1);
const tim=d=>num((d.getHours()*3600+d.getMinutes()*60+d.getSeconds())/86400,2);
const dtime=d=>num(excelDate(d),4);
function sheetXml(rows,widths){
  const sheetData=rows.map((cells,r)=>`<row r="${r+1}">${cells.map((c,i)=>{
    const cell=c&&typeof c==='object'&&'t' in c?c:txt(c);
    const ref=`${col(i+1)}${r+1}`;
    if(cell.t==='n')return `<c r="${ref}" s="${cell.s||0}"><v>${cell.v}</v></c>`;
    return `<c r="${ref}" s="${r===0?5:0}" t="inlineStr"><is><t xml:space="preserve">${esc(cell.v)}</t></is></c>`;
  }).join('')}</row>`).join('');
  const cols=widths.map((w,i)=>`<col min="${i+1}" max="${i+1}" width="${w}" customWidth="1"/>`).join('');
  const last=`${col(Math.max(widths.length,rows[0].length))}${rows.length}`;
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:${last}"/><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>${cols}</cols><sheetData>${sheetData}</sheetData><autoFilter ref="A1:${last}"/></worksheet>`;
}
const styles=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="4"><numFmt numFmtId="164" formatCode="dd.mm.yyyy"/><numFmt numFmtId="165" formatCode="hh:mm"/><numFmt numFmtId="166" formatCode="0.00"/><numFmt numFmtId="167" formatCode="dd.mm.yyyy hh:mm"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Aptos"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Aptos"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF183153"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="6"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="166" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="167" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="1" fillId="1" borderId="0" xfId="0"/></cellXfs></styleSheet>`;
const encoder=new TextEncoder();
const crcTable=(()=>{const t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0;}return t;})();
function crc32(bytes){let c=0xFFFFFFFF;for(const v of bytes)c=crcTable[(c^v)&255]^(c>>>8);return(c^0xFFFFFFFF)>>>0;}
const writeU16=(v,n)=>{v.push(n&255,(n>>>8)&255);};
const writeU32=(v,n)=>{v.push(n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255);};
function zipEntries(files){
 const chunks=[], central=[]; let offset=0;
 const push=b=>{chunks.push(b);offset+=b.length;};
 for(const [name,contents] of files){
  const nb=encoder.encode(name),db=encoder.encode(contents),crc=crc32(db),start=offset;
  const head=[];writeU32(head,0x04034b50);writeU16(head,20);writeU16(head,0x0800);writeU16(head,0);writeU16(head,0);writeU16(head,0);writeU32(head,crc);writeU32(head,db.length);writeU32(head,db.length);writeU16(head,nb.length);writeU16(head,0);
  push(new Uint8Array(head));push(nb);push(db);
  const meta=[];writeU32(meta,0x02014b50);writeU16(meta,20);writeU16(meta,20);writeU16(meta,0x0800);writeU16(meta,0);writeU16(meta,0);writeU16(meta,0);writeU32(meta,crc);writeU32(meta,db.length);writeU32(meta,db.length);writeU16(meta,nb.length);writeU16(meta,0);writeU16(meta,0);writeU16(meta,0);writeU16(meta,0);writeU32(meta,0);writeU32(meta,start);
  central.push(new Uint8Array(meta),nb);
 }
 const cdStart=offset;for(const item of central)push(item);
 const end=[];writeU32(end,0x06054b50);writeU16(end,0);writeU16(end,0);writeU16(end,files.length);writeU16(end,files.length);writeU32(end,offset-cdStart);writeU32(end,cdStart);writeU16(end,0);push(new Uint8Array(end));
 const bytes=new Uint8Array(offset);let p=0;for(const chunk of chunks){bytes.set(chunk,p);p+=chunk.length;}
 return bytes;
}
export function makeXlsx(shifts){
 const ordered=[...shifts].sort((a,b)=>a.start.localeCompare(b.start));
 const workRows=[['Datum Beginn','Uhrzeit Beginn','Datum Ende','Uhrzeit Ende','Arbeitsstunden','Startstandort','Endstandort','Start GPS','Ende GPS','Notiz']];
 const nightRows=[['Datum','Beginn','Ende','Abschnitt','Nachtstunden','Startstandort der Schicht','Endstandort der Schicht','Schicht-ID']];
 const totals=new Map();
 for(const shift of ordered){
  const a=new Date(shift.start),b=new Date(shift.end);
  const coord=l=>l&&Number.isFinite(l.lat)&&Number.isFinite(l.lon)?`${l.lat.toFixed(6)}, ${l.lon.toFixed(6)}`:'';
  workRows.push([dte(a),tim(a),dte(b),tim(b),num(hoursRounded(b-a)),txt(locationText(shift.startLoc)),txt(locationText(shift.endLoc)),txt(coord(shift.startLoc)),txt(coord(shift.endLoc)),txt(shift.note||'')]);
  for(const part of splitDays(shift)) {const row=totals.get(part.day)||{day:part.day,work:0,night:0};row.work+=part.ms;totals.set(part.day,row);}
  for(const part of splitNight(shift)){
    const row=totals.get(part.day)||{day:part.day,work:0,night:0};row.night+=part.ms;totals.set(part.day,row);
    nightRows.push([dte(new Date(`${part.day}T12:00:00`)),tim(part.start),tim(part.end),txt(part.kind),num(hoursRounded(part.ms)),txt(locationText(part.startLoc)),txt(locationText(part.endLoc)),txt(part.shiftId)]);
  }
 }
 nightRows.splice(1,nightRows.length-1,...nightRows.slice(1).sort((a,b)=>a[0].v-b[0].v||a[1].v-b[1].v));
 const overview=[['Datum','Arbeitsstunden (gerundet)','Nachtstunden (gerundet)']];
 for(const row of [...totals.values()].sort((a,b)=>a.day.localeCompare(b.day)))overview.push([dte(new Date(`${row.day}T12:00:00`)),num(hoursRounded(row.work)),num(hoursRounded(row.night))]);
 const names=['Arbeitszeiten','Nachtstunden','Tagesübersicht'];
 const workbook=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${names.map((n,i)=>`<sheet name="${n}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('')}</sheets></workbook>`;
 const wbRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${names.map((_,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')}<Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;
 const types=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${names.map((_,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`;
 const rootRels=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`;
 const files=[['[Content_Types].xml',types],['_rels/.rels',rootRels],['xl/workbook.xml',workbook],['xl/_rels/workbook.xml.rels',wbRels],['xl/styles.xml',styles],['xl/worksheets/sheet1.xml',sheetXml(workRows,[18,15,18,15,19,26,26,24,24,40])],['xl/worksheets/sheet2.xml',sheetXml(nightRows,[18,15,15,16,18,28,28,28])],['xl/worksheets/sheet3.xml',sheetXml(overview,[18,26,26])]];
 return new Blob([zipEntries(files)],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
}
