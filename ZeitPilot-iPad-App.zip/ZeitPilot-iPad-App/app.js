import {splitNight, monthlySummary, hoursRounded, localKey, monthKey, dateText, timeText, dateTimeText, decimalText, locationText, validateShift} from './logic.js';
import {makeXlsx} from './xlsx.js';
const KEY='zeitpilot.v1';
const $=selector=>document.querySelector(selector);
let state={shifts:[],active:null,settings:{reverseGeocode:false}},currentTab='shifts',pending=false,toastTimer=null;
const uuid=()=>globalThis.crypto?.randomUUID?.() || `s-${Date.now()}-${Math.random().toString(36).slice(2)}`;
function save(){try{localStorage.setItem(KEY,JSON.stringify(state));$('#save-status').textContent='● Lokal gespeichert';return true;}catch(e){toast('Speichern fehlgeschlagen! Speicherplatz prüfen und Backup erstellen.');return false;}}
function load(){try{const raw=localStorage.getItem(KEY);if(raw){const read=JSON.parse(raw);if(Array.isArray(read.shifts))state.shifts=read.shifts.filter(validateShift);if(read.active?.start && !read.active.end)state.active=read.active;if(read.settings)state.settings.reverseGeocode=Boolean(read.settings.reverseGeocode);}}catch(e){toast('Gespeicherte Daten konnten nicht gelesen werden.');}}
function toast(s){const box=$('#toast');box.textContent=s;box.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{box.hidden=true;},6500);}
function locLabel(location){return locationText(location)}
function safe(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function makeShiftId(){return uuid();}
function toLocalInput(date){const d=new Date(date);return `${localKey(d)}T${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;}
async function getLocation(){
 if(!('geolocation' in navigator))return {error:'GPS auf diesem Gerät nicht verfügbar'};
 let pos;
 try{pos=await new Promise((resolve,reject)=>navigator.geolocation.getCurrentPosition(resolve,reject,{enableHighAccuracy:true,maximumAge:15000,timeout:13000}));}
 catch(err){return {error:err.code===1?'Standortzugriff verweigert':err.code===3?'Standortabfrage dauerte zu lange':'Standort nicht verfügbar'};}
 const result={lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:pos.coords.accuracy,name:''};
 if(state.settings.reverseGeocode&&navigator.onLine){
   try{const u=new URL('https://nominatim.openstreetmap.org/reverse');u.searchParams.set('format','jsonv2');u.searchParams.set('lat',String(result.lat));u.searchParams.set('lon',String(result.lon));u.searchParams.set('zoom','12');u.searchParams.set('addressdetails','1');u.searchParams.set('accept-language','de');const response=await fetch(u,{headers:{'Accept':'application/json'},signal:AbortSignal.timeout(7000)});if(response.ok){const geo=await response.json();const a=geo.address||{};result.name=a.city||a.town||a.village||a.municipality||a.county||'';}}catch(e){/* GPS bleibt erhalten */}
 }
 return {location:result};
}
async function handleClock(){
 if(pending)return;
 pending=true;const button=$('#clock-button');button.disabled=true;
 const ending=Boolean(state.active),stamp=new Date().toISOString();let id;
 // Erst Zeitstempel dauerhaft sichern, dann GPS unabhängig davon abfragen.
 if(ending){
   const active=state.active;
   if(new Date(stamp)<=new Date(active.start)){toast('Ende muss nach Arbeitsbeginn liegen.');pending=false;button.disabled=false;render();return;}
   id=active.id;
   state.shifts.push({id,start:active.start,end:stamp,startLoc:active.startLoc||null,endLoc:null,note:active.note||''});
   state.active=null;
 }else{
   id=makeShiftId();state.active={id,start:stamp,startLoc:null,note:''};
 }
 save();render();$('#clock-label').textContent='GPS-Standort wird ermittelt …';
 const geo=await getLocation();
 if(ending){const shift=state.shifts.find(s=>s.id===id);if(shift)shift.endLoc=geo.location||null;}
 else if(state.active?.id===id)state.active.startLoc=geo.location||null;
 save();pending=false;button.disabled=false;render();
 toast(geo.error?`${ending?'Arbeitsende':'Arbeitsbeginn'} gespeichert. ${geo.error}; Standort kann ergänzt werden.`:`${ending?'Arbeitsende':'Arbeitsbeginn'} und GPS-Standort gespeichert.`);
}

function render(){
 const now=new Date(),month=$('#month-select').value||monthKey(now),working=Boolean(state.active);
 const clock=$('#current-clock');clock.textContent=working?timeText(new Date(state.active.start)):timeText(now);
 $('#work-badge').textContent=working?'Im Dienst':'Nicht eingestempelt';$('#work-badge').classList.toggle('active',working);
 $('#hero-detail').textContent=working?`Beginn: ${dateTimeText(new Date(state.active.start))} · ${locLabel(state.active.startLoc)}`:'Bereit für deinen nächsten Einsatz.';
 $('#clock-button').classList.toggle('stop',working);$('#clock-glyph').textContent=working?'■':'▶';
 if(!pending)$('#clock-label').textContent=working?'Arbeitsende erfassen':'Arbeitsbeginn erfassen';
 const summary=monthlySummary(state.shifts,month,state.active,now);
 $('#work-hours').innerHTML=`${decimalText(hoursRounded(summary.reduce((s,r)=>s+r.workedMs,0)))} <small>Std.</small>`;
 $('#night-hours').innerHTML=`${decimalText(hoursRounded(summary.reduce((s,r)=>s+r.nightMs,0)))} <small>Std.</small>`;
 $('#shift-count').textContent=state.shifts.filter(s=>monthKey(new Date(s.start))===month).length+(working&&monthKey(new Date(state.active.start))===month?1:0);
 if(currentTab==='shifts')renderShifts(month);
 if(currentTab==='nights')renderNights(month);
}
function renderShifts(month){
 const list=$('#shift-list');const shifts=state.shifts.filter(s=>monthKey(new Date(s.start))===month||monthKey(new Date(s.end))===month).sort((a,b)=>b.start.localeCompare(a.start));
 if(!shifts.length){list.innerHTML='<div class="empty"><strong>Noch keine Arbeitszeiten vorhanden</strong>Tippe oben auf „Arbeitsbeginn erfassen“ oder trage einen Einsatz nach.</div>';return;}
 list.innerHTML=shifts.map(s=>{const a=new Date(s.start),b=new Date(s.end),diff=hoursRounded(b-a);
 return `<article class="entry"><div><div class="entry-head"><strong>${dateText(a)}</strong><span class="period">${timeText(a)} – ${timeText(b)}${localKey(a)!==localKey(b)?' (+ Folgetag)':''}</span></div><div class="entry-info"><span>⌖ ${safe(locLabel(s.startLoc))} → ${safe(locLabel(s.endLoc))}</span>${s.note?`<span>✎ ${safe(s.note)}</span>`:''}</div></div><div class="entry-right"><strong>${decimalText(diff)} h</strong><button type="button" data-edit="${safe(s.id)}">Bearbeiten</button></div></article>`;}).join('');
}
function renderNights(month){const list=$('#night-list');const items=state.shifts.flatMap(splitNight).filter(p=>p.day.startsWith(month)).sort((a,b)=>b.day.localeCompare(a.day)||b.start-a.start);
 if(!items.length){list.innerHTML='<div class="empty"><strong>Keine Nachtstunden in diesem Monat</strong>Es zählen Arbeitszeiten zwischen 22:00 und 6:00 Uhr.</div>';return;}
 list.innerHTML=items.map(p=>`<article class="entry"><div><div class="entry-head"><strong>${dateText(new Date(`${p.day}T12:00:00`))}</strong><span class="period">${timeText(p.start)} – ${timeText(p.end)} · ${p.kind}</span></div><div class="entry-info"><span>Standorte der Schicht: ${safe(locLabel(p.startLoc))} → ${safe(locLabel(p.endLoc))}</span></div></div><div class="entry-right"><strong>${decimalText(hoursRounded(p.ms))} h</strong></div></article>`).join('');
}
function setTab(tab){currentTab=tab;for(const b of document.querySelectorAll('.tab'))b.classList.toggle('active',b.dataset.tab===tab);for(const id of ['shifts','nights','settings'])$(`#panel-${id}`).hidden=id!==tab;render();}
function showModal(shift=null){const start=shift?new Date(shift.start):new Date(),end=shift?new Date(shift.end):new Date(Date.now()+3600000);
 $('#dialog-title').textContent=shift?'Einsatz bearbeiten':'Arbeitszeit nachtragen';$('#edit-id').value=shift?.id||'';
 $('#edit-start').value=toLocalInput(start);$('#edit-end').value=toLocalInput(end);$('#edit-start-place').value=shift?.startLoc?.name||'';$('#edit-end-place').value=shift?.endLoc?.name||'';$('#edit-note').value=shift?.note||'';
 $('#delete-shift').hidden=!shift;$('#edit-dialog').showModal();}
function shiftFromForm(){const start=$('#edit-start').value,end=$('#edit-end').value,id=$('#edit-id').value;
 if(!start||!end){toast('Bitte Beginn und Ende eingeben.');return null;}
 const a=new Date(start),b=new Date(end);if(!(b>a)){toast('Das Arbeitsende muss nach dem Arbeitsbeginn liegen.');return null;}
 if(b-a>400*86400000){toast('Eine Schicht darf höchstens 400 Tage dauern.');return null;}
 const old=state.shifts.find(s=>s.id===id)||null;const startLoc={...(old?.startLoc||{}),name:$('#edit-start-place').value.trim()},endLoc={...(old?.endLoc||{}),name:$('#edit-end-place').value.trim()};
 return {id:id||makeShiftId(),start:a.toISOString(),end:b.toISOString(),startLoc,endLoc,note:$('#edit-note').value.trim()};
}
async function download(blob,name){
 const file=new File([blob],name,{type:blob.type||'application/octet-stream'});
 if(navigator.canShare?.({files:[file]}))try{await navigator.share({files:[file],title:name});return;}catch(err){if(err.name==='AbortError')return;}
 const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=name;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
}
function backup(){return new Blob([JSON.stringify({app:'ZeitPilot',version:1,created:new Date().toISOString(),...state},null,2)],{type:'application/json'});}
async function restore(file){if(!file)return;let val;try{val=JSON.parse(await file.text());}catch{toast('Diese Datei enthält kein gültiges JSON.');return;}
 if(val.app!=='ZeitPilot'||!Array.isArray(val.shifts)||!val.shifts.every(validateShift)){toast('Ungültige ZeitPilot-Sicherung.');return;}
 if(!confirm(`Sicherung mit ${val.shifts.length} Einsätzen einlesen? Deine bisherigen Daten werden dadurch ersetzt.`))return;
 state={shifts:val.shifts,active:val.active?.start&&!val.active.end?val.active:null,settings:{reverseGeocode:Boolean(val.settings?.reverseGeocode)}};
 $('#reverse-geocode').checked=state.settings.reverseGeocode;save();render();toast('Datensicherung erfolgreich wiederhergestellt.');
}
function init(){load();$('#month-select').value=monthKey(new Date());$('#reverse-geocode').checked=state.settings.reverseGeocode;
 $('#clock-button').addEventListener('click',handleClock);$('#month-select').addEventListener('change',render);
 for(const b of document.querySelectorAll('.tab'))b.addEventListener('click',()=>setTab(b.dataset.tab));
 $('#add-shift').addEventListener('click',()=>showModal());
 $('#shift-list').addEventListener('click',e=>{const b=e.target.closest('[data-edit]');if(!b)return;const shift=state.shifts.find(s=>s.id===b.dataset.edit);if(shift)showModal(shift);});
 $('#close-dialog').addEventListener('click',()=>$('#edit-dialog').close());$('#cancel-edit').addEventListener('click',()=>$('#edit-dialog').close());
 $('#edit-form').addEventListener('submit',e=>{e.preventDefault();const shift=shiftFromForm();if(!shift)return;const index=state.shifts.findIndex(s=>s.id===shift.id);if(index>=0)state.shifts[index]=shift;else state.shifts.push(shift);save();$('#edit-dialog').close();render();toast('Arbeitszeit gespeichert.');});
 $('#delete-shift').addEventListener('click',()=>{const id=$('#edit-id').value;if(!id)return;if(!confirm('Diesen Einsatz endgültig löschen?'))return;state.shifts=state.shifts.filter(s=>s.id!==id);save();$('#edit-dialog').close();render();toast('Einsatz gelöscht.');});
 $('#reverse-geocode').addEventListener('change',e=>{state.settings.reverseGeocode=e.target.checked;save();toast(e.target.checked?'Ortsnamen-Abfrage aktiviert. GPS wird an OpenStreetMap übermittelt.':'Ortsnamen-Abfrage deaktiviert.');});
 $('#excel-export').addEventListener('click',async()=>{try{await download(makeXlsx(state.shifts),`ZeitPilot-${localKey(new Date())}.xlsx`);}catch(err){console.error(err);toast('Excel-Export fehlgeschlagen.');}});
 $('#backup-export').addEventListener('click',()=>download(backup(),`ZeitPilot-Backup-${localKey(new Date())}.json`).catch(()=>toast('Backup konnte nicht gespeichert werden.')));
 $('#backup-import').addEventListener('click',()=>$('#backup-file').click());$('#backup-file').addEventListener('change',async e=>{await restore(e.target.files[0]);e.target.value='';});
 render();setInterval(()=>{if(document.visibilityState==='visible')render();},30000);
 if('serviceWorker' in navigator && location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(()=>{});
}
init();
